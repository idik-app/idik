"use client";
import { useState } from "react";
import { usePasien } from "./context/PasienContext";
import ModalTambahPasien from "./components/ModalTambahPasien";
import PatientDetailModal from "./components/PatientDetailModal";
import PasienModalForm from "./components/PasienModalForm";
import PasienTable from "./components/PasienTable";

export default function PasienContent() {
  const { selected, setSelected, editing, setEditing } = usePasien();
  const [showAdd, setShowAdd] = useState(false);

  return (
    <>
      <div className="flex justify-between mb-3">
        <h2 className="text-gold text-lg font-semibold">🧾 Daftar Pasien</h2>
        <button
          onClick={() => setShowAdd(true)}
          className="px-4 py-2 bg-cyan-600/40 hover:bg-cyan-500/70 border border-cyan-400/30 rounded-lg
                     hover:shadow-[0_0_10px_rgba(0,255,255,0.5)] transition-all"
        >
          ➕ Tambah Pasien
        </button>
      </div>

      <PasienTable />

      {/* Modal Tambah */}
      {showAdd && <ModalTambahPasien onClose={() => setShowAdd(false)} />}

      {/* Modal View */}
      {selected && (
        <PatientDetailModal
          patient={selected}
          onClose={() => setSelected(null)}
        />
      )}

      {/* Modal Edit */}
      {editing && (
        <PasienModalForm
          patient={editing}
          onClose={() => setEditing(null)}
          onSave={() => setEditing(null)}
        />
      )}
    </>
  );
}
