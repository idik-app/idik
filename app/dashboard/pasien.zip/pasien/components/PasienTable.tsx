"use client";
import { usePasien } from "../context/PasienContext";
import { Eye, Pencil, Trash } from "react-bootstrap-icons";

export default function PasienTable() {
  // ✅ Tambahkan setEditing dari context
  const { currentPageData, deletePasien, setSelected, setEditing } =
    usePasien();

  return (
    <div className="overflow-x-auto border border-cyan-800/40 rounded-xl bg-gradient-to-b from-[#0a0f14]/80 to-[#0b1016]/80">
      <table className="w-full text-sm text-left border-collapse">
        <thead className="bg-gradient-to-r from-cyan-900/40 to-yellow-900/20 text-cyan-300">
          <tr>
            <th className="px-3 py-2">No</th>
            <th className="px-3 py-2">No. RM</th>
            <th className="px-3 py-2">Nama Pasien</th>
            <th className="px-3 py-2">JK</th>
            <th className="px-3 py-2">Umur</th>
            <th className="px-3 py-2">Gol. Darah</th>
            <th className="px-3 py-2">Alamat</th>
            <th className="px-3 py-2 text-center">Aksi</th>
          </tr>
        </thead>
        <tbody>
          {currentPageData.length > 0 ? (
            currentPageData.map((p, i) => (
              <tr
                key={p.rm}
                className="border-b border-cyan-800/40 hover:bg-cyan-900/10 transition-colors"
              >
                <td className="px-3 py-2">{i + 1}</td>
                <td className="px-3 py-2">{p.rm}</td>
                <td className="px-3 py-2">{p.nama}</td>
                <td className="px-3 py-2">{p.jk}</td>
                <td className="px-3 py-2">{p.umur}</td>
                <td className="px-3 py-2">{p.goldar}</td>
                <td className="px-3 py-2">{p.alamat}</td>
                <td className="px-3 py-2 text-center">
                  <div className="flex justify-center gap-3">
                    {/* 👁 View */}
                    <button
                      className="text-cyan-300 hover:text-cyan-400"
                      onClick={() => setSelected(p)}
                    >
                      <Eye size={16} />
                    </button>

                    {/* ✏️ Edit */}
                    <button
                      className="text-yellow-400 hover:text-yellow-500"
                      onClick={() => setEditing(p)} // ✅ Tambahkan ini
                    >
                      <Pencil size={16} />
                    </button>

                    {/* 🗑 Delete */}
                    <button
                      className="text-red-400 hover:text-red-500"
                      onClick={() =>
                        confirm(`Hapus pasien ${p.nama}?`) && deletePasien(p.rm)
                      }
                    >
                      <Trash size={16} />
                    </button>
                  </div>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan={8} className="text-center py-4 text-gray-500 italic">
                Tidak ada data ditemukan.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
