"use client";
import { usePasien } from "../context/PasienContext";
import { Search } from "react-bootstrap-icons";

export default function PasienToolbar() {
  const {
    searchQuery,
    setSearchQuery,
    page,
    setPage,
    totalPages,
    perPage,
    setPerPage,
  } = usePasien();

  const disabledPrev = page <= 1;
  const disabledNext = page >= totalPages;

  return (
    <div className="jarvis-glass flex flex-col md:flex-row justify-between items-center gap-3 p-3 rounded-xl border border-cyan-700/40 shadow-[0_0_15px_rgba(0,255,255,0.1)]">
      {/* Search Input */}
      <div className="flex items-center gap-2 w-full md:w-auto">
        <Search className="text-cyan-400" size={18} />
        <input
          type="text"
          placeholder="Cari pasien..."
          className="w-full md:w-72 bg-transparent border-b border-cyan-700 text-cyan-200 placeholder-cyan-600 outline-none px-2 pb-1 text-sm focus:border-yellow-400 transition-all"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      {/* Pagination Controls + Per Page */}
      <div className="flex flex-wrap items-center justify-center md:justify-end gap-3 text-sm text-cyan-300 font-medium">
        <div className="flex items-center gap-1">
          <span className="text-cyan-400">Tampilkan:</span>
          <select
            value={perPage}
            onChange={(e) => setPerPage(Number(e.target.value))}
            className="bg-transparent border border-cyan-700 text-cyan-200 rounded-md px-2 py-1 focus:border-yellow-400 transition"
          >
            <option value={10}>10</option>
            <option value={25}>25</option>
            <option value={100}>100</option>
          </select>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => !disabledPrev && setPage(page - 1)}
            disabled={disabledPrev}
            className={`transition ${
              disabledPrev
                ? "opacity-40 cursor-not-allowed"
                : "hover:text-yellow-400"
            }`}
          >
            ◀ Prev
          </button>

          <span className="text-cyan-200">
            Hal {page} / {totalPages}
          </span>

          <button
            onClick={() => !disabledNext && setPage(page + 1)}
            disabled={disabledNext}
            className={`transition ${
              disabledNext
                ? "opacity-40 cursor-not-allowed"
                : "hover:text-yellow-400"
            }`}
          >
            Next ▶
          </button>
        </div>
      </div>
    </div>
  );
}
