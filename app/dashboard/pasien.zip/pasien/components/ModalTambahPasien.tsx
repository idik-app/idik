"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X } from "lucide-react";
import { usePasien } from "../context/PasienContext";

export default function ModalTambahPasien({
  onClose,
}: {
  onClose: () => void;
}) {
  const { addPasien } = usePasien();

  const [formData, setFormData] = useState({
    nama: "",
    jk: "",
    umur: "",
    goldar: "",
    alamat: "",
  });

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.nama.trim() || !formData.jk.trim() || !formData.umur.trim()) {
      alert("Lengkapi data wajib: Nama, Jenis Kelamin, dan Umur");
      return;
    }

    addPasien({
      rm: "", // akan diisi otomatis oleh context
      nama: formData.nama.trim(),
      jk: formData.jk,
      umur: Number(formData.umur),
      goldar: formData.goldar || "-",
      alamat: formData.alamat.trim() || "-",
    });

    onClose(); // ✅ tutup modal otomatis setelah tambah
  };

  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/70 backdrop-blur-md"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
      >
        <motion.form
          onSubmit={handleSubmit}
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          transition={{ duration: 0.3, ease: "easeOut" }}
          className="relative bg-gradient-to-b from-cyan-950/50 to-black/70 border border-cyan-400/30
                     shadow-[0_0_25px_rgba(0,255,255,0.2)] rounded-2xl p-6 w-[520px] text-white"
        >
          {/* Tombol Tutup */}
          <button
            type="button"
            onClick={onClose}
            className="absolute top-3 right-3 text-cyan-300 hover:text-gold transition-all"
          >
            <X size={20} />
          </button>

          {/* Judul Modal */}
          <h2 className="text-2xl text-gold mb-5 text-center">
            ➕ Tambah Pasien Baru
          </h2>

          {/* Isi Form */}
          <div className="space-y-3 text-sm">
            <div>
              <label className="text-cyan-400">Nama Pasien *</label>
              <input
                name="nama"
                value={formData.nama}
                onChange={handleChange}
                className="w-full mt-1 px-3 py-2 bg-cyan-900/30 border border-cyan-600/40 rounded-lg"
                placeholder="Masukkan nama lengkap"
              />
            </div>

            <div>
              <label className="text-cyan-400">Jenis Kelamin *</label>
              <select
                name="jk"
                value={formData.jk}
                onChange={handleChange}
                className="w-full mt-1 px-3 py-2 bg-cyan-900/30 border border-cyan-600/40 rounded-lg"
              >
                <option value="">Pilih Jenis Kelamin</option>
                <option value="L">Laki-laki</option>
                <option value="P">Perempuan</option>
              </select>
            </div>

            <div>
              <label className="text-cyan-400">Umur *</label>
              <input
                name="umur"
                type="number"
                min="0"
                value={formData.umur}
                onChange={handleChange}
                className="w-full mt-1 px-3 py-2 bg-cyan-900/30 border border-cyan-600/40 rounded-lg"
                placeholder="Contoh: 45"
              />
            </div>

            <div>
              <label className="text-cyan-400">Golongan Darah</label>
              <select
                name="goldar"
                value={formData.goldar}
                onChange={handleChange}
                className="w-full mt-1 px-3 py-2 bg-cyan-900/30 border border-cyan-600/40 rounded-lg"
              >
                <option value="">Pilih Golongan Darah</option>
                <option value="A">A</option>
                <option value="B">B</option>
                <option value="AB">AB</option>
                <option value="O">O</option>
              </select>
            </div>

            <div>
              <label className="text-cyan-400">Alamat</label>
              <input
                name="alamat"
                value={formData.alamat}
                onChange={handleChange}
                className="w-full mt-1 px-3 py-2 bg-cyan-900/30 border border-cyan-600/40 rounded-lg"
                placeholder="Alamat pasien"
              />
            </div>
          </div>

          {/* Tombol Simpan */}
          <div className="mt-6 flex justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-cyan-500/50 rounded-lg hover:bg-cyan-700/40 transition"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-cyan-600/50 hover:bg-cyan-500/70 rounded-lg border border-cyan-400/30 
                         hover:shadow-[0_0_10px_rgba(0,255,255,0.5)] transition-all"
            >
              Simpan
            </button>
          </div>
        </motion.form>
      </motion.div>
    </AnimatePresence>
  );
}
