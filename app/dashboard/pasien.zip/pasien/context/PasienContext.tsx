"use client";

import {
  createContext,
  useContext,
  useState,
  useMemo,
  useEffect,
  ReactNode,
} from "react";
import { dummyPasien } from "../data/dummyPasien";

/* =====================================
   🧠 Type & Interface Definition
===================================== */
export interface Pasien {
  rm: string;
  nama: string;
  jk: string;
  umur: number;
  goldar: string;
  alamat: string;
  nik?: string;
  tempat?: string;
  lahir?: string;
  hp?: string;
  darurat?: string;
}

interface PasienContextType {
  data: Pasien[];
  filtered: Pasien[];
  addPasien: (p: Pasien) => void;
  editPasien: (rm: string, updated: Partial<Pasien>) => void;
  deletePasien: (rm: string) => void;

  // selection & editing state
  selected: Pasien | null;
  setSelected: (p: Pasien | null) => void;
  editing: Pasien | null;
  setEditing: (p: Pasien | null) => void;

  // search & pagination
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  page: number;
  setPage: (n: number) => void;
  perPage: number;
  setPerPage: (n: number) => void;
  totalPages: number;
  currentPageData: Pasien[];
  loading: boolean;
}

/* =====================================
   ⚙️ Context Setup
===================================== */
const PasienContext = createContext<PasienContextType | undefined>(undefined);

export function PasienProvider({ children }: { children: ReactNode }) {
  /* ------------------------------
     🧩 State
  ------------------------------ */
  const [data, setData] = useState<Pasien[]>(dummyPasien);
  const [selected, setSelected] = useState<Pasien | null>(null);
  const [editing, setEditing] = useState<Pasien | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [page, setPage] = useState(1);
  const [perPage, setPerPage] = useState(10);
  const [loading, setLoading] = useState(true);

  /* ------------------------------
     💫 Simulasi Loading (Shimmer)
  ------------------------------ */
  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 1200);
    return () => clearTimeout(timer);
  }, []);

  /* ------------------------------
     ➕ Tambah, ✏️ Edit, 🗑 Hapus
  ------------------------------ */
  const addPasien = (p: Pasien) =>
    setData((prev) => [...prev, { ...p, rm: String(prev.length + 1001) }]);

  const editPasien = (rm: string, updated: Partial<Pasien>) => {
    setData((prev) =>
      prev.map((p) => (p.rm === rm ? { ...p, ...updated } : p))
    );
    setEditing(null); // ✅ tutup panel edit otomatis
  };

  const deletePasien = (rm: string) =>
    setData((prev) => prev.filter((p) => p.rm !== rm));

  /* ------------------------------
     🔍 Search Filter (case-insensitive)
  ------------------------------ */
  const filtered = useMemo(() => {
    if (!searchQuery.trim()) return data;
    const q = searchQuery.toLowerCase();
    return data.filter(
      (p) =>
        p.nama.toLowerCase().includes(q) ||
        p.rm.toLowerCase().includes(q) ||
        p.jk.toLowerCase().includes(q) ||
        p.goldar.toLowerCase().includes(q) ||
        p.alamat.toLowerCase().includes(q)
    );
  }, [data, searchQuery]);

  /* ------------------------------
     📄 Pagination
  ------------------------------ */
  const totalPages = Math.max(1, Math.ceil(filtered.length / perPage));
  const currentPageData = useMemo(() => {
    const start = (page - 1) * perPage;
    return filtered.slice(start, start + perPage);
  }, [filtered, page, perPage]);

  // reset halaman ke 1 setiap kali filter atau jumlah tampil berubah
  useEffect(() => {
    setPage(1);
  }, [searchQuery, perPage]);

  /* ------------------------------
     🧠 Provider Output
  ------------------------------ */
  return (
    <PasienContext.Provider
      value={{
        data,
        filtered,
        addPasien,
        editPasien,
        deletePasien,
        selected,
        setSelected,
        editing,
        setEditing,
        searchQuery,
        setSearchQuery,
        page,
        setPage,
        perPage,
        setPerPage,
        totalPages,
        currentPageData,
        loading,
      }}
    >
      {children}
    </PasienContext.Provider>
  );
}

/* =====================================
   🔗 Hook Accessor
===================================== */
export const usePasien = () => {
  const ctx = useContext(PasienContext);
  if (!ctx)
    throw new Error("❌ usePasien() must be used within a <PasienProvider>");
  return ctx;
};
