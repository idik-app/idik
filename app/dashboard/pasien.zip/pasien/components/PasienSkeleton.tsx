"use client";

export default function PasienSkeleton() {
  return (
    <div className="jarvis-glass animate-fade-slide-up rounded-xl border border-cyan-800/40 p-5 mt-4 overflow-hidden relative">
      {/* Efek hologram scan */}
      <div className="absolute inset-0 animate-hologram-scan opacity-40 rounded-xl"></div>

      {/* Header skeleton */}
      <div className="flex justify-between items-center mb-4 relative z-10">
        <div className="h-5 w-48 bg-cyan-900/30 rounded-md animate-pulse-glow"></div>
        <div className="h-4 w-12 bg-cyan-900/20 rounded-md"></div>
      </div>

      {/* Grid shimmer */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 relative z-10">
        {/* Kolom kiri */}
        <div className="space-y-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <div
              key={`left-${i}`}
              className="h-4 bg-cyan-900/20 rounded-md animate-[pulse_2s_infinite_ease-in-out]"
            ></div>
          ))}
        </div>

        {/* Kolom kanan */}
        <div className="space-y-3">
          {Array.from({ length: 5 }).map((_, i) => (
            <div
              key={`right-${i}`}
              className="h-4 bg-cyan-900/20 rounded-md animate-[pulse_2s_infinite_ease-in-out]"
            ></div>
          ))}
        </div>
      </div>

      {/* Footer shimmer */}
      <div className="flex justify-end mt-5 pt-4 border-t border-cyan-800/30 relative z-10">
        <div className="h-8 w-32 bg-cyan-900/20 rounded-lg animate-[pulse_2s_infinite_ease-in-out]"></div>
      </div>
    </div>
  );
}
