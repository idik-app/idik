"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X } from "lucide-react";

interface Patient {
  id?: string;
  nama: string;
  no_rm: string;
  tanggal: string;
}

interface ModalFormProps {
  patient: Patient | null;
  onClose: () => void;
  onSave: (updated: Patient) => void;
}

export default function PasienModalForm({
  patient,
  onClose,
  onSave,
}: ModalFormProps) {
  const [formData, setFormData] = useState<Patient>(
    patient || { nama: "", no_rm: "", tanggal: "" }
  );

  // Autofocus field pertama saat modal dibuka
  useEffect(() => {
    if (typeof window !== "undefined") {
      const input =
        document.querySelector<HTMLInputElement>("input[name='nama']");
      input?.focus();
    }
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) =>
    setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
    onClose();
  };

  if (!patient) return null;

  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/70 backdrop-blur-md"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
      >
        <motion.form
          onSubmit={handleSubmit}
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          transition={{ duration: 0.3, ease: "easeOut" }}
          className="relative bg-gradient-to-b from-cyan-950/50 to-black/70 border border-cyan-400/30 
                     shadow-[0_0_25px_rgba(0,255,255,0.2)] rounded-2xl p-6 w-[420px] text-white
                     mobile:w-[90vw]"
        >
          {/* Tombol Close */}
          <button
            type="button"
            onClick={onClose}
            className="absolute top-3 right-3 text-cyan-300 hover:text-gold transition-all"
            aria-label="Tutup"
          >
            <X size={20} />
          </button>

          {/* Header */}
          <h2 className="text-2xl text-gold mb-5 text-center">
            ✏️ Edit Data Pasien
          </h2>

          {/* Field Form */}
          <div className="space-y-3 text-sm">
            <div>
              <label className="text-cyan-400">Nama Pasien</label>
              <input
                name="nama"
                value={formData.nama}
                onChange={handleChange}
                className="w-full mt-1 px-3 py-2 bg-cyan-900/30 border border-cyan-600/40 rounded-lg 
                           focus:outline-none focus:border-cyan-400"
                placeholder="Masukkan nama pasien"
              />
            </div>

            <div>
              <label className="text-cyan-400">No. RM</label>
              <input
                name="no_rm"
                value={formData.no_rm}
                onChange={handleChange}
                className="w-full mt-1 px-3 py-2 bg-cyan-900/30 border border-cyan-600/40 rounded-lg 
                           focus:outline-none focus:border-cyan-400"
                placeholder="Masukkan nomor rekam medis"
              />
            </div>

            <div>
              <label className="text-cyan-400">Tanggal</label>
              <input
                type="date"
                name="tanggal"
                value={formData.tanggal}
                onChange={handleChange}
                className="w-full mt-1 px-3 py-2 bg-cyan-900/30 border border-cyan-600/40 rounded-lg 
                           focus:outline-none focus:border-cyan-400"
              />
            </div>
          </div>

          {/* Tombol Aksi (dekat konten, bukan di bawah layar) */}
          <div className="mt-5 flex justify-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2 border border-cyan-500/50 rounded-lg hover:bg-cyan-700/40 transition-all"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-cyan-600/50 hover:bg-cyan-500/70 rounded-lg border border-cyan-400/30 
                         hover:shadow-[0_0_10px_rgba(0,255,255,0.5)] transition-all"
            >
              Simpan
            </button>
          </div>
        </motion.form>
      </motion.div>
    </AnimatePresence>
  );
}
