"use client";

import { motion, AnimatePresence } from "framer-motion";
import { X } from "lucide-react";

interface Patient {
  id?: string;
  nama: string;
  no_rm: string;
  jk?: string;
  umur?: number;
  goldar?: string;
  alamat?: string;
  tanggal?: string;
}

interface PatientDetailModalProps {
  patient: Patient | null;
  onClose: () => void;
}

export default function PatientDetailModal({
  patient,
  onClose,
}: PatientDetailModalProps) {
  if (!patient) return null;

  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/70 backdrop-blur-md"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          transition={{ duration: 0.3, ease: "easeOut" }}
          className="relative bg-gradient-to-b from-cyan-950/50 to-black/70 border border-cyan-400/30 
                     shadow-[0_0_25px_rgba(0,255,255,0.2)] rounded-2xl p-6 w-[420px] text-white"
        >
          {/* Tombol Close */}
          <button
            onClick={onClose}
            className="absolute top-3 right-3 text-cyan-300 hover:text-gold transition-all"
            aria-label="Tutup"
          >
            <X size={20} />
          </button>

          {/* Header */}
          <h2 className="text-2xl text-gold mb-4 text-center">
            👁️ Detail Biodata Pasien
          </h2>

          {/* Isi Biodata */}
          <div className="space-y-2 text-sm">
            <div className="flex justify-between border-b border-cyan-800/40 py-1">
              <span className="text-cyan-400">Nama</span>
              <span className="text-right">{patient.nama || "-"}</span>
            </div>
            <div className="flex justify-between border-b border-cyan-800/40 py-1">
              <span className="text-cyan-400">No. RM</span>
              <span className="text-right">{patient.no_rm || "-"}</span>
            </div>
            {patient.jk && (
              <div className="flex justify-between border-b border-cyan-800/40 py-1">
                <span className="text-cyan-400">Jenis Kelamin</span>
                <span className="text-right">{patient.jk}</span>
              </div>
            )}
            {patient.umur && (
              <div className="flex justify-between border-b border-cyan-800/40 py-1">
                <span className="text-cyan-400">Umur</span>
                <span className="text-right">{patient.umur} th</span>
              </div>
            )}
            {patient.goldar && (
              <div className="flex justify-between border-b border-cyan-800/40 py-1">
                <span className="text-cyan-400">Gol. Darah</span>
                <span className="text-right">{patient.goldar}</span>
              </div>
            )}
            {patient.alamat && (
              <div className="flex justify-between border-b border-cyan-800/40 py-1">
                <span className="text-cyan-400">Alamat</span>
                <span className="text-right max-w-[230px] break-words text-gray-300">
                  {patient.alamat}
                </span>
              </div>
            )}
            {patient.tanggal && (
              <div className="flex justify-between border-b border-cyan-800/40 py-1">
                <span className="text-cyan-400">Tanggal</span>
                <span className="text-right">{patient.tanggal}</span>
              </div>
            )}
          </div>

          {/* Tombol Tutup */}
          <div className="mt-5 flex justify-center">
            <button
              onClick={onClose}
              className="px-6 py-2 bg-cyan-600/40 hover:bg-cyan-500/60 border border-cyan-400/30 
                         rounded-lg text-sm transition-all hover:shadow-[0_0_10px_rgba(0,255,255,0.5)]"
            >
              Tutup
            </button>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
