"use client";
import { PasienProvider } from "./context/PasienContext";
import PasienContent from "./PasienContent";

export default function Page() {
  return (
    <PasienProvider>
      <PasienContent />
    </PasienProvider>
  );
}
